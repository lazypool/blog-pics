import torch
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer


tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")


class STS(Dataset):
    def __init__(self, data_file):
        self.data = self.load_data(data_file)

    def load_data(self, data_file):
        data = {}
        with open(data_file, "r") as file:
            for idx, line in enumerate(file):
                row = line.strip().split("\t")
                data[idx] = {"score": row[4], "sent1": row[5], "sent2": row[6]}
        return data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]


def collote_fn(batch_samples):
    batch_score, batch_sent1, batch_sent2 = [], [], []
    for sample in batch_samples:
        batch_score.append(float(sample["score"]))
        batch_sent1.append(sample["sent1"])
        batch_sent2.append(sample["sent2"])
    X = tokenizer(
        batch_sent1, batch_sent2, padding=True, truncation=True, return_tensors="pt"
    )
    y = torch.tensor(batch_score)
    return X, y


def build_dataloader():
    sts_train = STS("data/stsbenchmark/sts-train.csv")
    sts_test = STS("data/stsbenchmark/sts-test.csv")

    train_loader = DataLoader(
        sts_train, batch_size=4, shuffle=True, collate_fn=collote_fn
    )
    test_loader = DataLoader(
        sts_test, batch_size=4, shuffle=True, collate_fn=collote_fn
    )
    return train_loader, test_loader
