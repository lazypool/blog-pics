from torch import nn
from transformers import BertModel, BertConfig


class BertForSTS(BertModel):
    def __init__(self, config):
        super().__init__(config)
        self.bert = BertModel(config, add_pooling_layer=False)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.classifier = nn.Linear(768, 1)
        self.post_init()

    def forward(self, x):
        bert_output = self.bert(**x)
        cls_vectors = bert_output.last_hidden_state[:, 0, :]
        cls_vectors = self.dropout(cls_vectors)
        logits = self.classifier(cls_vectors)
        return logits


def build_model():
    config = BertConfig.from_pretrained("bert-base-uncased")
    model = BertForSTS.from_pretrained("bert-base-uncased", config=config)
    return model
