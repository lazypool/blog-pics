from transformers import AdamW, get_scheduler
from dataset import build_dataloader
from model import build_model
from train import train_loop, test_loop, loss_fn


learning_rate = 1e-5
epoch_num = 3


def main():
    train_loader, test_loader = build_dataloader()
    model = build_model()

    optimizer = AdamW(model.parameters(), lr=learning_rate)
    lr_scheduler = get_scheduler(
        "linear",
        optimizer=optimizer,
        num_warmup_steps=0,
        num_training_steps=epoch_num*len(train_loader)
    )

    total_loss = 0
    for t in range(epoch_num):
        print(f"Epoch {t+1}/{epoch_num}\n-------------------------------")
        total_loss = train_loop(train_loader, model, loss_fn, optimizer, lr_scheduler, t+1, total_loss)
        test_loop(test_loader, model, mode='Test')
    print("Done!")


if __name__ == '__main__':
    main()
